#include <stdio.h>

int main(int argc, const char * argv[]) {
    printf("Welcome to the Mutex class!\n");
    return 0;
}
